import { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, TextInput, Image, Alert } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ArrowLeft, Search, Star, Clock, Users, Play } from 'lucide-react-native';
import { useRouter } from 'expo-router';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

export default function CoursesPage() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const queryClient = useQueryClient();
  
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [sortBy, setSortBy] = useState('popular');

  const categories = [
    { id: 'all', name: 'All Courses' },
    { id: 'web-dev', name: 'Web Development' },
    { id: 'data-science', name: 'Data Science' },
    { id: 'mobile', name: 'Mobile Development' },
    { id: 'design', name: 'Design' },
    { id: 'business', name: 'Business' },
    { id: 'marketing', name: 'Marketing' }
  ];

  // Fetch courses with filters
  const { data: coursesData, isLoading, error } = useQuery({
    queryKey: ['courses', selectedCategory, searchTerm, sortBy],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (selectedCategory !== 'all') params.append('category', selectedCategory);
      if (searchTerm) params.append('search', searchTerm);
      if (sortBy) params.append('sortBy', sortBy);
      
      const response = await fetch(`/api/courses?${params}`);
      if (!response.ok) {
        throw new Error('Failed to fetch courses');
      }
      return response.json();
    },
  });

  // Enroll in course mutation
  const enrollMutation = useMutation({
    mutationFn: async (courseId) => {
      const response = await fetch('/api/courses/enroll', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          course_id: courseId, 
          student_email: 'student@example.com' // In real app, get from auth
        }),
      });
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to enroll');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['courses'] });
      Alert.alert('Success', 'Successfully enrolled in course!');
    },
    onError: (error) => {
      Alert.alert('Error', error.message);
    },
  });

  const courses = coursesData?.courses || [];

  const getLevelColor = (level) => {
    switch (level) {
      case 'Beginner':
        return '#10b981';
      case 'Intermediate':
        return '#f59e0b';
      case 'Advanced':
        return '#ef4444';
      default:
        return '#6b7280';
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#f9fafb', paddingTop: insets.top }}>
      <StatusBar style="dark" />
      
      {/* Header */}
      <View style={{ 
        backgroundColor: '#ffffff', 
        paddingHorizontal: 20, 
        paddingVertical: 16,
        borderBottomWidth: 1,
        borderBottomColor: '#e5e7eb',
        flexDirection: 'row',
        alignItems: 'center'
      }}>
        <TouchableOpacity 
          onPress={() => router.back()}
          style={{ marginRight: 16 }}
        >
          <ArrowLeft size={24} color="#111827" />
        </TouchableOpacity>
        <Text style={{ 
          fontSize: 20, 
          fontWeight: 'bold', 
          color: '#111827',
          flex: 1
        }}>
          Courses
        </Text>
      </View>

      <ScrollView 
        style={{ flex: 1 }} 
        contentContainerStyle={{ paddingBottom: insets.bottom + 20 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Search */}
        <View style={{ paddingHorizontal: 20, paddingVertical: 16 }}>
          <View style={{
            backgroundColor: '#ffffff',
            borderRadius: 12,
            paddingHorizontal: 16,
            paddingVertical: 12,
            flexDirection: 'row',
            alignItems: 'center',
            borderWidth: 1,
            borderColor: '#e5e7eb'
          }}>
            <Search size={20} color="#6b7280" />
            <TextInput
              placeholder="Search courses..."
              value={searchTerm}
              onChangeText={setSearchTerm}
              style={{
                flex: 1,
                marginLeft: 12,
                fontSize: 16,
                color: '#111827'
              }}
            />
          </View>
        </View>

        {/* Filters */}
        <View style={{ paddingHorizontal: 20, marginBottom: 16 }}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ flexGrow: 0 }}>
            {categories.map((category) => (
              <TouchableOpacity
                key={category.id}
                onPress={() => setSelectedCategory(category.id)}
                style={{
                  backgroundColor: selectedCategory === category.id ? '#2563eb' : '#ffffff',
                  paddingHorizontal: 16,
                  paddingVertical: 8,
                  borderRadius: 20,
                  marginRight: 8,
                  borderWidth: 1,
                  borderColor: selectedCategory === category.id ? '#2563eb' : '#e5e7eb'
                }}
              >
                <Text style={{
                  color: selectedCategory === category.id ? '#ffffff' : '#6b7280',
                  fontWeight: '500',
                  fontSize: 14
                }}>
                  {category.name}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* Loading State */}
        {isLoading && (
          <View style={{ alignItems: 'center', paddingVertical: 40 }}>
            <Text style={{ color: '#6b7280', fontSize: 16 }}>Loading courses...</Text>
          </View>
        )}

        {/* Error State */}
        {error && (
          <View style={{ alignItems: 'center', paddingVertical: 40, paddingHorizontal: 20 }}>
            <Text style={{ color: '#ef4444', fontSize: 16, textAlign: 'center', marginBottom: 16 }}>
              Error loading courses: {error.message}
            </Text>
            <TouchableOpacity 
              onPress={() => queryClient.invalidateQueries({ queryKey: ['courses'] })}
              style={{
                backgroundColor: '#2563eb',
                paddingHorizontal: 20,
                paddingVertical: 12,
                borderRadius: 8
              }}
            >
              <Text style={{ color: '#ffffff', fontWeight: '600' }}>Try Again</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* Results Count */}
        {!isLoading && !error && (
          <View style={{ paddingHorizontal: 20, marginBottom: 16 }}>
            <Text style={{ color: '#6b7280', fontSize: 14 }}>
              Showing {courses.length} courses
            </Text>
          </View>
        )}

        {/* Courses List */}
        {!isLoading && !error && (
          <View style={{ paddingHorizontal: 20 }}>
            {courses.map((course) => (
              <TouchableOpacity
                key={course.id}
                style={{
                  backgroundColor: '#ffffff',
                  borderRadius: 12,
                  marginBottom: 16,
                  shadowColor: '#000',
                  shadowOffset: { width: 0, height: 2 },
                  shadowOpacity: 0.1,
                  shadowRadius: 4,
                  elevation: 3
                }}
              >
                <Image 
                  source={{ 
                    uri: course.thumbnail_url || 'https://images.unsplash.com/photo-1627398242454-45a1465c2479?w=400&h=200&fit=crop'
                  }}
                  style={{ 
                    width: '100%', 
                    height: 180, 
                    borderTopLeftRadius: 12, 
                    borderTopRightRadius: 12 
                  }}
                />
                
                {/* Level Badge */}
                <View style={{
                  position: 'absolute',
                  top: 12,
                  left: 12,
                  backgroundColor: getLevelColor(course.level),
                  paddingHorizontal: 8,
                  paddingVertical: 4,
                  borderRadius: 6
                }}>
                  <Text style={{ color: '#ffffff', fontSize: 12, fontWeight: '600' }}>
                    {course.level}
                  </Text>
                </View>

                {/* Lessons Badge */}
                <View style={{
                  position: 'absolute',
                  top: 12,
                  right: 12,
                  backgroundColor: 'rgba(0, 0, 0, 0.7)',
                  paddingHorizontal: 8,
                  paddingVertical: 4,
                  borderRadius: 6,
                  flexDirection: 'row',
                  alignItems: 'center'
                }}>
                  <Play size={12} color="#ffffff" />
                  <Text style={{ color: '#ffffff', fontSize: 12, marginLeft: 4 }}>
                    {course.total_lessons} lessons
                  </Text>
                </View>
                
                <View style={{ padding: 16 }}>
                  <Text style={{ 
                    fontSize: 18, 
                    fontWeight: '600', 
                    color: '#111827',
                    marginBottom: 4
                  }}>
                    {course.title}
                  </Text>
                  <Text style={{ color: '#6b7280', marginBottom: 8 }}>
                    by {course.instructor_name}
                  </Text>
                  <Text style={{ color: '#6b7280', fontSize: 14, marginBottom: 12 }}>
                    {course.description}
                  </Text>
                  
                  <View style={{ 
                    flexDirection: 'row', 
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    marginBottom: 16
                  }}>
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 16 }}>
                      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                        <Clock size={14} color="#6b7280" />
                        <Text style={{ color: '#6b7280', fontSize: 12, marginLeft: 4 }}>
                          {course.duration_hours}h
                        </Text>
                      </View>
                      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                        <Users size={14} color="#6b7280" />
                        <Text style={{ color: '#6b7280', fontSize: 12, marginLeft: 4 }}>
                          {course.enrolled_students?.toLocaleString() || 0}
                        </Text>
                      </View>
                    </View>
                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                      <Star size={14} color="#fbbf24" />
                      <Text style={{ color: '#111827', fontSize: 12, marginLeft: 4, fontWeight: '500' }}>
                        {course.rating || 0}
                      </Text>
                    </View>
                  </View>
                  
                  <View style={{ 
                    flexDirection: 'row', 
                    justifyContent: 'space-between',
                    alignItems: 'center'
                  }}>
                    <Text style={{ fontSize: 20, fontWeight: 'bold', color: '#2563eb' }}>
                      ${course.price}
                    </Text>
                    <TouchableOpacity 
                      onPress={() => enrollMutation.mutate(course.id)}
                      disabled={enrollMutation.isLoading}
                      style={{
                        backgroundColor: enrollMutation.isLoading ? '#9ca3af' : '#2563eb',
                        paddingHorizontal: 20,
                        paddingVertical: 10,
                        borderRadius: 8
                      }}
                    >
                      <Text style={{ 
                        color: '#ffffff', 
                        fontWeight: '600',
                        fontSize: 14
                      }}>
                        {enrollMutation.isLoading ? 'Enrolling...' : 'Enroll Now'}
                      </Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        )}

        {/* No Results */}
        {!isLoading && !error && courses.length === 0 && (
          <View style={{ alignItems: 'center', paddingVertical: 40, paddingHorizontal: 20 }}>
            <Search size={64} color="#d1d5db" />
            <Text style={{ 
              fontSize: 18, 
              fontWeight: '600', 
              color: '#111827',
              marginTop: 16,
              marginBottom: 8
            }}>
              No courses found
            </Text>
            <Text style={{ 
              color: '#6b7280', 
              textAlign: 'center',
              marginBottom: 20
            }}>
              Try adjusting your search terms or filters to find what you're looking for.
            </Text>
            <TouchableOpacity 
              onPress={() => {
                setSearchTerm('');
                setSelectedCategory('all');
                setSortBy('popular');
              }}
              style={{
                backgroundColor: '#2563eb',
                paddingHorizontal: 20,
                paddingVertical: 12,
                borderRadius: 8
              }}
            >
              <Text style={{ color: '#ffffff', fontWeight: '600' }}>
                Clear All Filters
              </Text>
            </TouchableOpacity>
          </View>
        )}
      </ScrollView>
    </View>
  );
}