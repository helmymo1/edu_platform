import { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, TextInput, Alert } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ArrowLeft, Search, Calendar, Clock, Users, Video } from 'lucide-react-native';
import { useRouter } from 'expo-router';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

export default function LiveLessonsPage() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const queryClient = useQueryClient();
  
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedTimeSlot, setSelectedTimeSlot] = useState('all');

  const categories = [
    { id: 'all', name: 'All Categories' },
    { id: 'web-dev', name: 'Web Development' },
    { id: 'data-science', name: 'Data Science' },
    { id: 'mobile', name: 'Mobile Development' },
    { id: 'design', name: 'Design' },
    { id: 'business', name: 'Business' },
    { id: 'marketing', name: 'Marketing' }
  ];

  const timeSlots = [
    { id: 'all', name: 'All Times' },
    { id: 'morning', name: 'Morning' },
    { id: 'afternoon', name: 'Afternoon' },
    { id: 'evening', name: 'Evening' }
  ];

  // Fetch live lessons with filters
  const { data: lessonsData, isLoading, error } = useQuery({
    queryKey: ['live-lessons', selectedCategory, searchTerm, selectedTimeSlot],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (selectedCategory !== 'all') params.append('category', selectedCategory);
      if (searchTerm) params.append('search', searchTerm);
      if (selectedTimeSlot !== 'all') params.append('timeSlot', selectedTimeSlot);
      
      const response = await fetch(`/api/live-lessons?${params}`);
      if (!response.ok) {
        throw new Error('Failed to fetch live lessons');
      }
      return response.json();
    },
  });

  // Book lesson mutation
  const bookMutation = useMutation({
    mutationFn: async (lessonId) => {
      const response = await fetch('/api/live-lessons/book', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          live_lesson_id: lessonId, 
          student_email: 'student@example.com', // In real app, get from auth
          student_name: 'John Doe' // In real app, get from auth
        }),
      });
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to book lesson');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['live-lessons'] });
      Alert.alert('Success', 'Successfully booked the live lesson!');
    },
    onError: (error) => {
      Alert.alert('Error', error.message);
    },
  });

  const liveLessons = lessonsData?.lessons || [];

  const getAvailableSpots = (lesson) => {
    return lesson.available_spots || (lesson.max_students - lesson.enrolled_students);
  };

  const getLevelColor = (level) => {
    switch (level) {
      case 'Beginner':
        return '#10b981';
      case 'Intermediate':
        return '#f59e0b';
      case 'Advanced':
        return '#ef4444';
      default:
        return '#6b7280';
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const formatTime = (timeString) => {
    return new Date(`2000-01-01T${timeString}`).toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#f9fafb', paddingTop: insets.top }}>
      <StatusBar style="dark" />
      
      {/* Header */}
      <View style={{ 
        backgroundColor: '#ffffff', 
        paddingHorizontal: 20, 
        paddingVertical: 16,
        borderBottomWidth: 1,
        borderBottomColor: '#e5e7eb',
        flexDirection: 'row',
        alignItems: 'center'
      }}>
        <TouchableOpacity 
          onPress={() => router.back()}
          style={{ marginRight: 16 }}
        >
          <ArrowLeft size={24} color="#111827" />
        </TouchableOpacity>
        <Text style={{ 
          fontSize: 20, 
          fontWeight: 'bold', 
          color: '#111827',
          flex: 1
        }}>
          Live Lessons
        </Text>
      </View>

      <ScrollView 
        style={{ flex: 1 }} 
        contentContainerStyle={{ paddingBottom: insets.bottom + 20 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Search */}
        <View style={{ paddingHorizontal: 20, paddingVertical: 16 }}>
          <View style={{
            backgroundColor: '#ffffff',
            borderRadius: 12,
            paddingHorizontal: 16,
            paddingVertical: 12,
            flexDirection: 'row',
            alignItems: 'center',
            borderWidth: 1,
            borderColor: '#e5e7eb'
          }}>
            <Search size={20} color="#6b7280" />
            <TextInput
              placeholder="Search live lessons..."
              value={searchTerm}
              onChangeText={setSearchTerm}
              style={{
                flex: 1,
                marginLeft: 12,
                fontSize: 16,
                color: '#111827'
              }}
            />
          </View>
        </View>

        {/* Category Filters */}
        <View style={{ paddingHorizontal: 20, marginBottom: 8 }}>
          <Text style={{ fontSize: 14, fontWeight: '600', color: '#111827', marginBottom: 8 }}>
            Category
          </Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ flexGrow: 0 }}>
            {categories.map((category) => (
              <TouchableOpacity
                key={category.id}
                onPress={() => setSelectedCategory(category.id)}
                style={{
                  backgroundColor: selectedCategory === category.id ? '#7c3aed' : '#ffffff',
                  paddingHorizontal: 16,
                  paddingVertical: 8,
                  borderRadius: 20,
                  marginRight: 8,
                  borderWidth: 1,
                  borderColor: selectedCategory === category.id ? '#7c3aed' : '#e5e7eb'
                }}
              >
                <Text style={{
                  color: selectedCategory === category.id ? '#ffffff' : '#6b7280',
                  fontWeight: '500',
                  fontSize: 14
                }}>
                  {category.name}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* Time Filters */}
        <View style={{ paddingHorizontal: 20, marginBottom: 16 }}>
          <Text style={{ fontSize: 14, fontWeight: '600', color: '#111827', marginBottom: 8 }}>
            Time
          </Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ flexGrow: 0 }}>
            {timeSlots.map((slot) => (
              <TouchableOpacity
                key={slot.id}
                onPress={() => setSelectedTimeSlot(slot.id)}
                style={{
                  backgroundColor: selectedTimeSlot === slot.id ? '#7c3aed' : '#ffffff',
                  paddingHorizontal: 16,
                  paddingVertical: 8,
                  borderRadius: 20,
                  marginRight: 8,
                  borderWidth: 1,
                  borderColor: selectedTimeSlot === slot.id ? '#7c3aed' : '#e5e7eb'
                }}
              >
                <Text style={{
                  color: selectedTimeSlot === slot.id ? '#ffffff' : '#6b7280',
                  fontWeight: '500',
                  fontSize: 14
                }}>
                  {slot.name}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* Loading State */}
        {isLoading && (
          <View style={{ alignItems: 'center', paddingVertical: 40 }}>
            <Text style={{ color: '#6b7280', fontSize: 16 }}>Loading live lessons...</Text>
          </View>
        )}

        {/* Error State */}
        {error && (
          <View style={{ alignItems: 'center', paddingVertical: 40, paddingHorizontal: 20 }}>
            <Text style={{ color: '#ef4444', fontSize: 16, textAlign: 'center', marginBottom: 16 }}>
              Error loading live lessons: {error.message}
            </Text>
            <TouchableOpacity 
              onPress={() => queryClient.invalidateQueries({ queryKey: ['live-lessons'] })}
              style={{
                backgroundColor: '#7c3aed',
                paddingHorizontal: 20,
                paddingVertical: 12,
                borderRadius: 8
              }}
            >
              <Text style={{ color: '#ffffff', fontWeight: '600' }}>Try Again</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* Results Count */}
        {!isLoading && !error && (
          <View style={{ paddingHorizontal: 20, marginBottom: 16 }}>
            <Text style={{ color: '#6b7280', fontSize: 14 }}>
              Showing {liveLessons.length} upcoming live lessons
            </Text>
          </View>
        )}

        {/* Live Lessons List */}
        {!isLoading && !error && (
          <View style={{ paddingHorizontal: 20 }}>
            {liveLessons.map((lesson) => (
              <TouchableOpacity
                key={lesson.id}
                style={{
                  backgroundColor: '#ffffff',
                  borderRadius: 12,
                  padding: 16,
                  marginBottom: 16,
                  borderLeftWidth: 4,
                  borderLeftColor: '#7c3aed',
                  shadowColor: '#000',
                  shadowOffset: { width: 0, height: 2 },
                  shadowOpacity: 0.1,
                  shadowRadius: 4,
                  elevation: 3
                }}
              >
                {/* Header */}
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
                  <View style={{ flex: 1, marginRight: 12 }}>
                    <Text style={{ 
                      fontSize: 18, 
                      fontWeight: '600', 
                      color: '#111827',
                      marginBottom: 4
                    }}>
                      {lesson.title}
                    </Text>
                    <Text style={{ color: '#6b7280', marginBottom: 8 }}>
                      with {lesson.instructor_name}
                    </Text>
                  </View>
                  
                  <View style={{ alignItems: 'flex-end' }}>
                    <View style={{
                      backgroundColor: getLevelColor(lesson.level),
                      paddingHorizontal: 8,
                      paddingVertical: 4,
                      borderRadius: 6,
                      marginBottom: 8
                    }}>
                      <Text style={{ color: '#ffffff', fontSize: 12, fontWeight: '600' }}>
                        {lesson.level}
                      </Text>
                    </View>
                    <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#7c3aed' }}>
                      ${lesson.price}
                    </Text>
                  </View>
                </View>

                {/* Description */}
                <Text style={{ color: '#6b7280', fontSize: 14, marginBottom: 12 }}>
                  {lesson.description}
                </Text>

                {/* Topics */}
                {lesson.topics && lesson.topics.length > 0 && (
                  <View style={{ marginBottom: 12 }}>
                    <Text style={{ fontSize: 14, fontWeight: '600', color: '#111827', marginBottom: 6 }}>
                      What you'll learn:
                    </Text>
                    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
                      {lesson.topics.slice(0, 3).map((topic, index) => (
                        <View key={index} style={{
                          backgroundColor: '#f3f4f6',
                          paddingHorizontal: 8,
                          paddingVertical: 4,
                          borderRadius: 6
                        }}>
                          <Text style={{ color: '#6b7280', fontSize: 12 }}>
                            {topic}
                          </Text>
                        </View>
                      ))}
                      {lesson.topics.length > 3 && (
                        <View style={{
                          backgroundColor: '#f3f4f6',
                          paddingHorizontal: 8,
                          paddingVertical: 4,
                          borderRadius: 6
                        }}>
                          <Text style={{ color: '#6b7280', fontSize: 12 }}>
                            +{lesson.topics.length - 3} more
                          </Text>
                        </View>
                      )}
                    </View>
                  </View>
                )}

                {/* Session Details */}
                <View style={{
                  backgroundColor: '#f9fafb',
                  borderRadius: 8,
                  padding: 12,
                  marginBottom: 12
                }}>
                  <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 }}>
                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                      <Calendar size={16} color="#6b7280" />
                      <Text style={{ color: '#6b7280', fontSize: 14, marginLeft: 6 }}>
                        {formatDate(lesson.scheduled_date)}
                      </Text>
                    </View>
                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                      <Clock size={16} color="#6b7280" />
                      <Text style={{ color: '#6b7280', fontSize: 14, marginLeft: 6 }}>
                        {formatTime(lesson.scheduled_time)} {lesson.timezone}
                      </Text>
                    </View>
                  </View>
                  
                  <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                      <Video size={16} color="#6b7280" />
                      <Text style={{ color: '#6b7280', fontSize: 14, marginLeft: 6 }}>
                        {lesson.duration_hours}h live session
                      </Text>
                    </View>
                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                      <Users size={16} color="#6b7280" />
                      <Text style={{ color: '#6b7280', fontSize: 14, marginLeft: 6 }}>
                        {getAvailableSpots(lesson)} spots left
                      </Text>
                    </View>
                  </View>
                </View>

                {/* Enrollment Progress */}
                <View style={{ marginBottom: 16 }}>
                  <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 }}>
                    <Text style={{ color: '#6b7280', fontSize: 12 }}>
                      Enrolled: {lesson.enrolled_students}/{lesson.max_students}
                    </Text>
                    <Text style={{ color: '#6b7280', fontSize: 12 }}>
                      {Math.round((lesson.enrolled_students / lesson.max_students) * 100)}% full
                    </Text>
                  </View>
                  <View style={{
                    backgroundColor: '#e5e7eb',
                    height: 6,
                    borderRadius: 3,
                    overflow: 'hidden'
                  }}>
                    <View style={{
                      backgroundColor: '#7c3aed',
                      height: '100%',
                      width: `${(lesson.enrolled_students / lesson.max_students) * 100}%`,
                      borderRadius: 3
                    }} />
                  </View>
                </View>

                {/* Actions */}
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Text style={{
                    color: getAvailableSpots(lesson) > 0 ? '#059669' : '#ef4444',
                    fontSize: 14,
                    fontWeight: '600'
                  }}>
                    {getAvailableSpots(lesson) > 0 
                      ? `${getAvailableSpots(lesson)} spots available`
                      : 'Fully booked'
                    }
                  </Text>
                  
                  <TouchableOpacity 
                    onPress={() => bookMutation.mutate(lesson.id)}
                    disabled={getAvailableSpots(lesson) === 0 || bookMutation.isLoading}
                    style={{
                      backgroundColor: getAvailableSpots(lesson) > 0 && !bookMutation.isLoading 
                        ? '#7c3aed' 
                        : '#9ca3af',
                      paddingHorizontal: 20,
                      paddingVertical: 10,
                      borderRadius: 8
                    }}
                  >
                    <Text style={{ 
                      color: '#ffffff', 
                      fontWeight: '600',
                      fontSize: 14
                    }}>
                      {bookMutation.isLoading ? 'Booking...' : 
                       getAvailableSpots(lesson) > 0 ? 'Book Lesson' : 'Fully Booked'}
                    </Text>
                  </TouchableOpacity>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        )}

        {/* No Results */}
        {!isLoading && !error && liveLessons.length === 0 && (
          <View style={{ alignItems: 'center', paddingVertical: 40, paddingHorizontal: 20 }}>
            <Calendar size={64} color="#d1d5db" />
            <Text style={{ 
              fontSize: 18, 
              fontWeight: '600', 
              color: '#111827',
              marginTop: 16,
              marginBottom: 8
            }}>
              No live lessons found
            </Text>
            <Text style={{ 
              color: '#6b7280', 
              textAlign: 'center',
              marginBottom: 20
            }}>
              Try adjusting your search terms or filters to find available sessions.
            </Text>
            <TouchableOpacity 
              onPress={() => {
                setSearchTerm('');
                setSelectedCategory('all');
                setSelectedTimeSlot('all');
              }}
              style={{
                backgroundColor: '#7c3aed',
                paddingHorizontal: 20,
                paddingVertical: 12,
                borderRadius: 8
              }}
            >
              <Text style={{ color: '#ffffff', fontWeight: '600' }}>
                Clear All Filters
              </Text>
            </TouchableOpacity>
          </View>
        )}

        {/* Info Section */}
        <View style={{ 
          backgroundColor: '#ffffff', 
          marginHorizontal: 20, 
          borderRadius: 12,
          padding: 20,
          marginTop: 24,
          marginBottom: 24
        }}>
          <Text style={{ 
            fontSize: 18, 
            fontWeight: 'bold', 
            color: '#111827',
            textAlign: 'center',
            marginBottom: 16
          }}>
            Why Choose Live Lessons?
          </Text>
          
          <View style={{ gap: 16 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <View style={{
                backgroundColor: '#ede9fe',
                width: 40,
                height: 40,
                borderRadius: 20,
                alignItems: 'center',
                justifyContent: 'center',
                marginRight: 12
              }}>
                <Video size={20} color="#7c3aed" />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 14, fontWeight: '600', color: '#111827', marginBottom: 2 }}>
                  Real-time Interaction
                </Text>
                <Text style={{ color: '#6b7280', fontSize: 12 }}>
                  Ask questions and get immediate feedback
                </Text>
              </View>
            </View>
            
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <View style={{
                backgroundColor: '#dbeafe',
                width: 40,
                height: 40,
                borderRadius: 20,
                alignItems: 'center',
                justifyContent: 'center',
                marginRight: 12
              }}>
                <Users size={20} color="#2563eb" />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 14, fontWeight: '600', color: '#111827', marginBottom: 2 }}>
                  Small Class Sizes
                </Text>
                <Text style={{ color: '#6b7280', fontSize: 12 }}>
                  Limited enrollment for personalized attention
                </Text>
              </View>
            </View>
            
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <View style={{
                backgroundColor: '#dcfce7',
                width: 40,
                height: 40,
                borderRadius: 20,
                alignItems: 'center',
                justifyContent: 'center',
                marginRight: 12
              }}>
                <Clock size={20} color="#16a34a" />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 14, fontWeight: '600', color: '#111827', marginBottom: 2 }}>
                  Hands-on Practice
                </Text>
                <Text style={{ color: '#6b7280', fontSize: 12 }}>
                  Follow along with live coding exercises
                </Text>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}