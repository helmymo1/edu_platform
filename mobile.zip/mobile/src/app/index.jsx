import { View, Text, ScrollView, TouchableOpacity, Image } from "react-native";
import { StatusBar } from "expo-status-bar";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  BookOpen,
  Play,
  Calendar,
  Users,
  Star,
  Clock,
} from "lucide-react-native";
import { useRouter } from "expo-router";

export default function Index() {
  const insets = useSafeAreaInsets();
  const router = useRouter();

  const featuredCourses = [
    {
      id: 1,
      title: "JavaScript Fundamentals",
      instructor: "Sarah Johnson",
      duration: "8 hours",
      rating: 4.8,
      students: 1250,
      price: "$89",
      thumbnail:
        "https://images.unsplash.com/photo-1627398242454-45a1465c2479?w=300&h=200&fit=crop",
    },
    {
      id: 2,
      title: "React Development",
      instructor: "Mike Chen",
      duration: "12 hours",
      rating: 4.9,
      students: 890,
      price: "$129",
      thumbnail:
        "https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=300&h=200&fit=crop",
    },
  ];

  const upcomingLessons = [
    {
      id: 1,
      title: "Advanced React Patterns",
      instructor: "Alex Rodriguez",
      date: "Dec 28, 2024",
      time: "2:00 PM EST",
      spots: 5,
    },
    {
      id: 2,
      title: "Database Design Workshop",
      instructor: "Lisa Wang",
      date: "Dec 30, 2024",
      time: "10:00 AM EST",
      spots: 3,
    },
  ];

  return (
    <View
      style={{ flex: 1, backgroundColor: "#f9fafb", paddingTop: insets.top }}
    >
      <StatusBar style="dark" />

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: insets.bottom + 20 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View
          style={{
            backgroundColor: "#ffffff",
            paddingHorizontal: 20,
            paddingVertical: 16,
            borderBottomWidth: 1,
            borderBottomColor: "#e5e7eb",
          }}
        >
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <BookOpen size={32} color="#2563eb" />
              <Text
                style={{
                  fontSize: 24,
                  fontWeight: "bold",
                  color: "#111827",
                  marginLeft: 8,
                }}
              >
                EduPlatform
              </Text>
            </View>
            <TouchableOpacity
              style={{
                backgroundColor: "#2563eb",
                paddingHorizontal: 16,
                paddingVertical: 8,
                borderRadius: 8,
              }}
            >
              <Text style={{ color: "#ffffff", fontWeight: "600" }}>
                Sign In
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Hero Section */}
        <View
          style={{
            backgroundColor: "#2563eb",
            paddingHorizontal: 20,
            paddingVertical: 40,
            alignItems: "center",
          }}
        >
          <Text
            style={{
              fontSize: 32,
              fontWeight: "bold",
              color: "#ffffff",
              textAlign: "center",
              marginBottom: 12,
            }}
          >
            Learn Without Limits
          </Text>
          <Text
            style={{
              fontSize: 18,
              color: "#ffffff",
              textAlign: "center",
              marginBottom: 24,
              opacity: 0.9,
            }}
          >
            Access courses and book live lessons with expert instructors
          </Text>

          <View style={{ flexDirection: "row", gap: 12 }}>
            <TouchableOpacity
              onPress={() => router.push("/courses")}
              style={{
                backgroundColor: "#ffffff",
                paddingHorizontal: 20,
                paddingVertical: 12,
                borderRadius: 8,
                flex: 1,
              }}
            >
              <Text
                style={{
                  color: "#2563eb",
                  fontWeight: "600",
                  textAlign: "center",
                }}
              >
                Browse Courses
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => router.push("/live-lessons")}
              style={{
                borderWidth: 2,
                borderColor: "#ffffff",
                paddingHorizontal: 20,
                paddingVertical: 12,
                borderRadius: 8,
                flex: 1,
              }}
            >
              <Text
                style={{
                  color: "#ffffff",
                  fontWeight: "600",
                  textAlign: "center",
                }}
              >
                Live Lessons
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Stats */}
        <View
          style={{
            backgroundColor: "#ffffff",
            paddingHorizontal: 20,
            paddingVertical: 32,
          }}
        >
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-around",
              flexWrap: "wrap",
              gap: 20,
            }}
          >
            <View style={{ alignItems: "center", minWidth: 80 }}>
              <Text
                style={{ fontSize: 24, fontWeight: "bold", color: "#2563eb" }}
              >
                10K+
              </Text>
              <Text style={{ color: "#6b7280", fontSize: 14 }}>Students</Text>
            </View>
            <View style={{ alignItems: "center", minWidth: 80 }}>
              <Text
                style={{ fontSize: 24, fontWeight: "bold", color: "#2563eb" }}
              >
                500+
              </Text>
              <Text style={{ color: "#6b7280", fontSize: 14 }}>Courses</Text>
            </View>
            <View style={{ alignItems: "center", minWidth: 80 }}>
              <Text
                style={{ fontSize: 24, fontWeight: "bold", color: "#2563eb" }}
              >
                100+
              </Text>
              <Text style={{ color: "#6b7280", fontSize: 14 }}>
                Instructors
              </Text>
            </View>
            <View style={{ alignItems: "center", minWidth: 80 }}>
              <Text
                style={{ fontSize: 24, fontWeight: "bold", color: "#2563eb" }}
              >
                98%
              </Text>
              <Text style={{ color: "#6b7280", fontSize: 14 }}>
                Satisfaction
              </Text>
            </View>
          </View>
        </View>

        {/* Featured Courses */}
        <View style={{ paddingHorizontal: 20, paddingVertical: 24 }}>
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: 16,
            }}
          >
            <Text
              style={{ fontSize: 20, fontWeight: "bold", color: "#111827" }}
            >
              Featured Courses
            </Text>
            <TouchableOpacity onPress={() => router.push("/courses")}>
              <Text style={{ color: "#2563eb", fontWeight: "600" }}>
                View All
              </Text>
            </TouchableOpacity>
          </View>

          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            style={{ flexGrow: 0 }}
          >
            {featuredCourses.map((course) => (
              <TouchableOpacity
                key={course.id}
                style={{
                  backgroundColor: "#ffffff",
                  borderRadius: 12,
                  marginRight: 16,
                  width: 280,
                  shadowColor: "#000",
                  shadowOffset: { width: 0, height: 2 },
                  shadowOpacity: 0.1,
                  shadowRadius: 4,
                  elevation: 3,
                }}
              >
                <Image
                  source={{ uri: course.thumbnail }}
                  style={{
                    width: "100%",
                    height: 160,
                    borderTopLeftRadius: 12,
                    borderTopRightRadius: 12,
                  }}
                />
                <View style={{ padding: 16 }}>
                  <Text
                    style={{
                      fontSize: 16,
                      fontWeight: "600",
                      color: "#111827",
                      marginBottom: 4,
                    }}
                  >
                    {course.title}
                  </Text>
                  <Text style={{ color: "#6b7280", marginBottom: 12 }}>
                    by {course.instructor}
                  </Text>

                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      alignItems: "center",
                      marginBottom: 12,
                    }}
                  >
                    <View
                      style={{ flexDirection: "row", alignItems: "center" }}
                    >
                      <Clock size={14} color="#6b7280" />
                      <Text
                        style={{
                          color: "#6b7280",
                          fontSize: 12,
                          marginLeft: 4,
                        }}
                      >
                        {course.duration}
                      </Text>
                    </View>
                    <View
                      style={{ flexDirection: "row", alignItems: "center" }}
                    >
                      <Star size={14} color="#fbbf24" />
                      <Text
                        style={{
                          color: "#111827",
                          fontSize: 12,
                          marginLeft: 4,
                          fontWeight: "500",
                        }}
                      >
                        {course.rating}
                      </Text>
                    </View>
                  </View>

                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      alignItems: "center",
                    }}
                  >
                    <Text
                      style={{
                        fontSize: 18,
                        fontWeight: "bold",
                        color: "#2563eb",
                      }}
                    >
                      {course.price}
                    </Text>
                    <TouchableOpacity
                      style={{
                        backgroundColor: "#2563eb",
                        paddingHorizontal: 16,
                        paddingVertical: 8,
                        borderRadius: 6,
                      }}
                    >
                      <Text
                        style={{
                          color: "#ffffff",
                          fontWeight: "600",
                          fontSize: 14,
                        }}
                      >
                        Enroll
                      </Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* Upcoming Live Lessons */}
        <View style={{ paddingHorizontal: 20, paddingVertical: 24 }}>
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: 16,
            }}
          >
            <Text
              style={{ fontSize: 20, fontWeight: "bold", color: "#111827" }}
            >
              Upcoming Live Lessons
            </Text>
            <TouchableOpacity onPress={() => router.push("/live-lessons")}>
              <Text style={{ color: "#7c3aed", fontWeight: "600" }}>
                View All
              </Text>
            </TouchableOpacity>
          </View>

          {upcomingLessons.map((lesson) => (
            <TouchableOpacity
              key={lesson.id}
              style={{
                backgroundColor: "#ffffff",
                borderRadius: 12,
                padding: 16,
                marginBottom: 12,
                borderLeftWidth: 4,
                borderLeftColor: "#7c3aed",
                shadowColor: "#000",
                shadowOffset: { width: 0, height: 1 },
                shadowOpacity: 0.05,
                shadowRadius: 2,
                elevation: 2,
              }}
            >
              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "space-between",
                  alignItems: "flex-start",
                }}
              >
                <View style={{ flex: 1 }}>
                  <Text
                    style={{
                      fontSize: 16,
                      fontWeight: "600",
                      color: "#111827",
                      marginBottom: 4,
                    }}
                  >
                    {lesson.title}
                  </Text>
                  <Text style={{ color: "#6b7280", marginBottom: 8 }}>
                    with {lesson.instructor}
                  </Text>

                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      marginBottom: 4,
                    }}
                  >
                    <Calendar size={14} color="#6b7280" />
                    <Text
                      style={{ color: "#6b7280", fontSize: 14, marginLeft: 6 }}
                    >
                      {lesson.date}
                    </Text>
                  </View>

                  <View style={{ flexDirection: "row", alignItems: "center" }}>
                    <Clock size={14} color="#6b7280" />
                    <Text
                      style={{ color: "#6b7280", fontSize: 14, marginLeft: 6 }}
                    >
                      {lesson.time}
                    </Text>
                  </View>
                </View>

                <View style={{ alignItems: "flex-end" }}>
                  <Text
                    style={{
                      color: "#059669",
                      fontSize: 12,
                      fontWeight: "600",
                      marginBottom: 8,
                    }}
                  >
                    {lesson.spots} spots left
                  </Text>
                  <TouchableOpacity
                    style={{
                      backgroundColor: "#7c3aed",
                      paddingHorizontal: 12,
                      paddingVertical: 6,
                      borderRadius: 6,
                    }}
                  >
                    <Text
                      style={{
                        color: "#ffffff",
                        fontWeight: "600",
                        fontSize: 12,
                      }}
                    >
                      Book Now
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            </TouchableOpacity>
          ))}
        </View>

        {/* Features */}
        <View
          style={{
            backgroundColor: "#ffffff",
            marginHorizontal: 20,
            borderRadius: 12,
            padding: 24,
            marginBottom: 24,
          }}
        >
          <Text
            style={{
              fontSize: 20,
              fontWeight: "bold",
              color: "#111827",
              textAlign: "center",
              marginBottom: 20,
            }}
          >
            Why Choose EduPlatform?
          </Text>

          <View style={{ gap: 20 }}>
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <View
                style={{
                  backgroundColor: "#dbeafe",
                  width: 48,
                  height: 48,
                  borderRadius: 24,
                  alignItems: "center",
                  justifyContent: "center",
                  marginRight: 16,
                }}
              >
                <Play size={24} color="#2563eb" />
              </View>
              <View style={{ flex: 1 }}>
                <Text
                  style={{
                    fontSize: 16,
                    fontWeight: "600",
                    color: "#111827",
                    marginBottom: 4,
                  }}
                >
                  On-Demand Learning
                </Text>
                <Text style={{ color: "#6b7280", fontSize: 14 }}>
                  Access courses anytime, anywhere with lifetime access
                </Text>
              </View>
            </View>

            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <View
                style={{
                  backgroundColor: "#ede9fe",
                  width: 48,
                  height: 48,
                  borderRadius: 24,
                  alignItems: "center",
                  justifyContent: "center",
                  marginRight: 16,
                }}
              >
                <Calendar size={24} color="#7c3aed" />
              </View>
              <View style={{ flex: 1 }}>
                <Text
                  style={{
                    fontSize: 16,
                    fontWeight: "600",
                    color: "#111827",
                    marginBottom: 4,
                  }}
                >
                  Live Sessions
                </Text>
                <Text style={{ color: "#6b7280", fontSize: 14 }}>
                  Interactive lessons with real-time Q&A and feedback
                </Text>
              </View>
            </View>

            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <View
                style={{
                  backgroundColor: "#dcfce7",
                  width: 48,
                  height: 48,
                  borderRadius: 24,
                  alignItems: "center",
                  justifyContent: "center",
                  marginRight: 16,
                }}
              >
                <Users size={24} color="#16a34a" />
              </View>
              <View style={{ flex: 1 }}>
                <Text
                  style={{
                    fontSize: 16,
                    fontWeight: "600",
                    color: "#111827",
                    marginBottom: 4,
                  }}
                >
                  Expert Instructors
                </Text>
                <Text style={{ color: "#6b7280", fontSize: 14 }}>
                  Learn from industry professionals and certified teachers
                </Text>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}
